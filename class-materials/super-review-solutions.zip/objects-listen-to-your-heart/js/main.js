//Create a stopwatch object that has four properties and three methods
